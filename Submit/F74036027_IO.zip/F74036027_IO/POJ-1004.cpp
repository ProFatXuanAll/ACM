#include <cstdio>
using namespace std;

int main()
{
	float money, average=0;

	for(int i=0;i<12;i++){
		scanf("%f",&money);
		
		average += money;
	}
	
	printf("$%.2f",average/12);
	
	return 0;
}
