#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int main()
{
	char start[12], end[5], cipher[300];

	fgets(start,12,stdin);
	while(strcmp(start,"ENDOFINPUT")){
		fgets(cipher,300,stdin);
		fgets(end,5,stdin);
	
		for(int i=0;i<strlen(cipher);i++){
			if(cipher[i]>='A'&&cipher[i]<='Z'){
				cipher[i] -= 'A';
				cipher[i] = (cipher[i]>=5)?cipher[i]-5+'A':cipher[i]+21+'A';
			}
			printf("%c",cipher[i]);
		}
		
		fgets(start,12,stdin);
	}
	
	return 0;
}
