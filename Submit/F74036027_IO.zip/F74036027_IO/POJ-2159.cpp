#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int match(char * sub_plain, char * cipher);

int main()
{
	char cipher[102], plaintext[102], test[102];
	
	fgets(cipher,102,stdin);
	cipher[strlen(cipher)-1]='\0';
	fgets(plaintext,102,stdin);
	plaintext[strlen(plaintext)-1]='\0';

	if(match(plaintext,cipher))
		printf("YES");
	else
		printf("NO");
	return 0;
}

int match(char * sub_plain, char * cipher)
{
	int alphabet[26][2]={0};
	int temp;
	
	for(int i=0;i<strlen(sub_plain);i++){
		alphabet[sub_plain[i]-'A'][0]++;
		alphabet[cipher[i]-'A'][1]++;
	}

	for(int i=25;i>0;i--){
		for(int j=0;j<i;j++){
			if(alphabet[j][0]>alphabet[j+1][0]){
				temp = alphabet[j][0];
				alphabet[j][0] = alphabet[j+1][0];
				alphabet[j+1][0]=temp;
			}
			
			if(alphabet[j][1]>alphabet[j+1][1]){
				temp = alphabet[j][1];
				alphabet[j][1] = alphabet[j+1][1];
				alphabet[j+1][1]=temp;
			}
		}
	}
	
	for(int i=0;i<26;i++){
		if(alphabet[i][0]!=alphabet[i][1])
			return 0;
	}
	
	return 1;
}
